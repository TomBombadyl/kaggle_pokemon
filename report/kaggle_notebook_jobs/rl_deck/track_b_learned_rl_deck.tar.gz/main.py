"""Kaggle cabt submission entry point."""

from __future__ import annotations

import os

from agent.agent import build_agent


# Kaggle loads this module via exec() without __file__; use cwd + known paths only.
KAGGLE_DECK = "/kaggle_simulations/agent/deck.csv"


def read_deck_csv() -> list[int]:
    file_path = "deck.csv"
    if not os.path.exists(file_path):
        file_path = KAGGLE_DECK
    with open(file_path, "r") as file:
        csv = file.read().split("\n")
    deck = []
    for i in range(60):
        deck.append(int(csv[i]))
    return deck


from agent.learned_policy import LearnedScorer

_AGENT = build_agent(seed=0, deck_path=KAGGLE_DECK, scorer=LearnedScorer())


def agent(obs_dict: dict) -> list[int]:
    if obs_dict.get("select") is None:
        return read_deck_csv()
    return _AGENT.act(obs_dict)
